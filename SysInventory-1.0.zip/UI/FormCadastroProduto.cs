using System;
using System.Windows.Forms;
using SysInventory.Models;
using SysInventory.DAL;

namespace SysInventory.UI
{
    public class FormCadastroProduto : Form
    {
        private TextBox txtNome;
        private TextBox txtDescricao;
        private NumericUpDown nudPreco;
        private NumericUpDown nudQuantidade;
        private Button btnSalvar;
        private Button btnCancelar;

        private Produto? produto;

        public FormCadastroProduto(Produto? produto = null)
        {
            this.produto = produto;
            InitializeComponent();
            if (produto != null) PreencherCampos(produto);
        }

        private void InitializeComponent()
        {
            Text = produto == null ? "Adicionar Produto" : "Editar Produto";
            Width = 400;
            Height = 320;
            StartPosition = FormStartPosition.CenterParent;

            var lblNome = new Label { Text = "Nome:", Left = 20, Top = 20 };
            txtNome = new TextBox { Left = 120, Top = 18, Width = 230 };

            var lblDescricao = new Label { Text = "Descrição:", Left = 20, Top = 60 };
            txtDescricao = new TextBox { Left = 120, Top = 58, Width = 230 };

            var lblPreco = new Label { Text = "Preço (R$):", Left = 20, Top = 100 };
            nudPreco = new NumericUpDown { Left = 120, Top = 98, Width = 120, DecimalPlaces = 2, Maximum = 1000000, Minimum = 0 };

            var lblQuantidade = new Label { Text = "Quantidade:", Left = 20, Top = 140 };
            nudQuantidade = new NumericUpDown { Left = 120, Top = 138, Width = 120, Maximum = 1000000, Minimum = 0 };

            btnSalvar = new Button { Text = "Salvar", Left = 120, Top = 190, Width = 100 };
            btnCancelar = new Button { Text = "Cancelar", Left = 250, Top = 190, Width = 100 };

            btnSalvar.Click += btnSalvar_Click;
            btnCancelar.Click += (s,e) => DialogResult = DialogResult.Cancel;

            Controls.AddRange(new Control[] { lblNome, txtNome, lblDescricao, txtDescricao, lblPreco, nudPreco, lblQuantidade, nudQuantidade, btnSalvar, btnCancelar });
        }

        private void PreencherCampos(Produto p)
        {
            txtNome.Text = p.Nome;
            txtDescricao.Text = p.Descricao;
            nudPreco.Value = p.Preco;
            nudQuantidade.Value = p.QuantidadeEmEstoque;
        }

        private void btnSalvar_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                MessageBox.Show("Nome é obrigatório.");
                return;
            }

            if (produto == null) produto = new Produto();

            produto.Nome = txtNome.Text;
            produto.Descricao = txtDescricao.Text;
            produto.Preco = nudPreco.Value;
            produto.QuantidadeEmEstoque = (int)nudQuantidade.Value;

            if (produto.Id == 0)
            {
                Database.AddProduto(produto);
            }
            else
            {
                Database.UpdateProduto(produto);
            }

            DialogResult = DialogResult.OK;
        }
    }
}
