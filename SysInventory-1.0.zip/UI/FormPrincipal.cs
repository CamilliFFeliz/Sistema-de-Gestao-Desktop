using System;
using System.Linq;
using System.Windows.Forms;
using SysInventory.DAL;
using SysInventory.Models;
using System.IO;
using System.Collections.Generic;

namespace SysInventory.UI
{
    public class FormPrincipal : Form
    {
        private DataGridView dgvProdutos;
        private Button btnAdicionar;
        private Button btnEditar;
        private Button btnExcluir;
        private MenuStrip menu;
        private ToolStripMenuItem relatoriosMenu;
        private ToolStripMenuItem gerarRelatorioItem;

        public FormPrincipal()
        {
            InitializeComponent();
            Load += FormPrincipal_Load;
        }

        private void InitializeComponent()
        {
            Text = "SysInventory - Gestão de Estoque";
            Width = 800;
            Height = 600;
            StartPosition = FormStartPosition.CenterScreen;

            menu = new MenuStrip();
            relatoriosMenu = new ToolStripMenuItem("Relatórios");
            gerarRelatorioItem = new ToolStripMenuItem("Gerar Relatório de Estoque");
            gerarRelatorioItem.Click += gerarRelatorioToolStripMenuItem_Click;
            relatoriosMenu.DropDownItems.Add(gerarRelatorioItem);
            menu.Items.Add(relatoriosMenu);
            Controls.Add(menu);

            dgvProdutos = new DataGridView { Dock = DockStyle.Top, Height = 400, ReadOnly = true, AutoGenerateColumns = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect };
            Controls.Add(dgvProdutos);

            btnAdicionar = new Button { Text = "Adicionar", Left = 20, Top = 420, Width = 100 };
            btnEditar = new Button { Text = "Editar", Left = 140, Top = 420, Width = 100 };
            btnExcluir = new Button { Text = "Excluir", Left = 260, Top = 420, Width = 100 };

            btnAdicionar.Click += btnAdicionar_Click;
            btnEditar.Click += btnEditar_Click;
            btnExcluir.Click += btnExcluir_Click;

            Controls.Add(btnAdicionar);
            Controls.Add(btnEditar);
            Controls.Add(btnExcluir);
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            CarregarProdutos();
        }

        private void CarregarProdutos()
        {
            var produtos = Database.GetProdutos();
            dgvProdutos.DataSource = null;
            dgvProdutos.DataSource = produtos;
            dgvProdutos.Columns["Id"].Width = 50;
            dgvProdutos.Columns["Nome"].Width = 200;
            dgvProdutos.Columns["Descricao"].Width = 250;
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            using (var form = new FormCadastroProduto())
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    CarregarProdutos();
                }
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvProdutos.SelectedRows.Count == 0) { MessageBox.Show("Selecione um produto para editar."); return; }
            var produto = dgvProdutos.SelectedRows[0].DataBoundItem as Produto;
            if (produto == null) return;

            using (var form = new FormCadastroProduto(produto))
            {
                if (form.ShowDialog() == DialogResult.OK)
                {
                    CarregarProdutos();
                }
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (dgvProdutos.SelectedRows.Count == 0) { MessageBox.Show("Selecione um produto para excluir."); return; }
            var produto = dgvProdutos.SelectedRows[0].DataBoundItem as Produto;
            if (produto == null) return;

            var resp = MessageBox.Show($"Deseja excluir o produto '{produto.Nome}'?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resp == DialogResult.Yes)
            {
                Database.DeleteProduto(produto.Id);
                CarregarProdutos();
            }
        }

        private void gerarRelatorioToolStripMenuItem_Click(object? sender, EventArgs e)
        {
            var produtos = Database.GetProdutos();
            string relatorio = "Relatório de Estoque - " + DateTime.Now.ToString("dd-MM-yyyy HH:mm") + "\r\n\r\n";
            relatorio += "ID | Nome | Preço | Quantidade\r\n";
            relatorio += "---------------------------------------\r\n";

            foreach (var produto in produtos)
            {
                relatorio += $"{produto.Id} | {produto.Nome} | R$ {produto.Preco:F2} | {produto.QuantidadeEmEstoque}\r\n";
            }

            var path = Path.Combine(Environment.CurrentDirectory, "RelatorioEstoque.txt");
            File.WriteAllText(path, relatorio);
            MessageBox.Show($"Relatório gerado: {path}", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
