using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using SysInventory.Models;

namespace SysInventory.DAL
{
    public static class Database
    {
        private static string connectionString = "Data Source=inventory.db;Version=3;";

        public static void InitializeDatabase()
        {
            if (!File.Exists("inventory.db"))
            {
                SQLiteConnection.CreateFile("inventory.db");
            }

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string createTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Produtos (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Nome TEXT NOT NULL,
                        Descricao TEXT,
                        Preco REAL NOT NULL,
                        QuantidadeEmEstoque INTEGER NOT NULL
                    );";
                using (var command = new SQLiteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        public static List<Produto> GetProdutos()
        {
            var produtos = new List<Produto>();
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = "SELECT * FROM Produtos";
                using (var command = new SQLiteCommand(sql, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        produtos.Add(new Produto
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Nome = reader["Nome"].ToString() ?? string.Empty,
                            Descricao = reader["Descricao"] == DBNull.Value ? string.Empty : reader["Descricao"].ToString() ?? string.Empty,
                            Preco = Convert.ToDecimal(reader["Preco"]),
                            QuantidadeEmEstoque = Convert.ToInt32(reader["QuantidadeEmEstoque"])
                        });
                    }
                }
            }
            return produtos;
        }

        public static void AddProduto(Produto produto)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = "INSERT INTO Produtos (Nome, Descricao, Preco, QuantidadeEmEstoque) VALUES (@Nome, @Descricao, @Preco, @Quantidade)";
                using (var command = new SQLiteCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@Nome", produto.Nome);
                    command.Parameters.AddWithValue("@Descricao", produto.Descricao);
                    command.Parameters.AddWithValue("@Preco", produto.Preco);
                    command.Parameters.AddWithValue("@Quantidade", produto.QuantidadeEmEstoque);
                    command.ExecuteNonQuery();
                }
            }
        }

        public static void UpdateProduto(Produto produto)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = "UPDATE Produtos SET Nome=@Nome, Descricao=@Descricao, Preco=@Preco, QuantidadeEmEstoque=@Quantidade WHERE Id=@Id";
                using (var command = new SQLiteCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@Nome", produto.Nome);
                    command.Parameters.AddWithValue("@Descricao", produto.Descricao);
                    command.Parameters.AddWithValue("@Preco", produto.Preco);
                    command.Parameters.AddWithValue("@Quantidade", produto.QuantidadeEmEstoque);
                    command.Parameters.AddWithValue("@Id", produto.Id);
                    command.ExecuteNonQuery();
                }
            }
        }

        public static void DeleteProduto(int id)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string sql = "DELETE FROM Produtos WHERE Id = @Id";
                using (var command = new SQLiteCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
